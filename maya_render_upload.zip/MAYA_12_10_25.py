def main():
    print("Welcome to MAYA! The app is running securely.")

if __name__ == "__main__":
    main()
